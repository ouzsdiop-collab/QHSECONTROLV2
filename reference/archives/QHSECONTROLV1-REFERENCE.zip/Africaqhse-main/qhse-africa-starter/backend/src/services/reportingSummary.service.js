import { prisma } from '../db.js';
import { TENANT_CONTEXT_REQUIRED_MESSAGE } from '../lib/tenantConstants.js';
import { normalizeTenantId, prismaTenantFilter } from '../lib/tenantScope.js';
import {
  buildPriorityAlerts,
  includesInsensitive,
  isActionOverdueDashboardRow,
  isIncidentLikelyOpen,
  isNcOpen,
  normalizeSiteId
} from './kpiCore.service.js';

const LIST_AUDITS = 6;
const LIST_NC = 8;
const LIST_ACTIONS = 8;
const LIST_CRITICAL_INCIDENTS = 6;
const RECENT_INCIDENT_SCAN = 400;
const DEFAULT_PERIOD_DAYS = 30;

/**
 * Filtre tenant obligatoire + site optionnel (jamais de requête sans `tenantId`).
 * @param {string} tenantId — identifiant normalisé non vide
 * @param {string | null} siteId
 */
function reportingSummaryWhere(tenantId, siteId) {
  const tf = prismaTenantFilter(tenantId);
  const sid = normalizeSiteId(siteId);
  const sitePart = sid ? { siteId: sid } : {};
  return { ...tf, ...sitePart };
}

/**
 * @param {string} tenantId
 * @param {string | null} siteId
 */
async function countActionsOverdueForReporting(tenantId, siteId) {
  const w = reportingSummaryWhere(tenantId, siteId);
  const rows = await prisma.action.findMany({
    where: w,
    select: { status: true, dueDate: true }
  });
  return rows.filter(isActionOverdueDashboardRow).length;
}

/**
 * @param {string} tenantId
 * @param {string | null} siteId
 */
async function countNonConformitiesOpenForReporting(tenantId, siteId) {
  const w = reportingSummaryWhere(tenantId, siteId);
  const rows = await prisma.nonConformity.findMany({
    where: w,
    select: { status: true }
  });
  return rows.filter((r) => isNcOpen(r.status)).length;
}

/**
 * Réponse vide (même forme que getReportingSummary) — ex. hors auth / sans tenant en base.
 */
export function buildEmptyReportingSummary(siteIdNormalized = null) {
  const generatedAt = new Date().toISOString();
  return {
    generatedAt,
    siteId: siteIdNormalized,
    counts: {
      incidentsTotal: 0,
      incidentsLast30Days: 0,
      incidentsCriticalOpen: 0,
      nonConformitiesTotal: 0,
      nonConformitiesOpen: 0,
      actionsTotal: 0,
      actionsOverdue: 0,
      auditsTotal: 0
    },
    kpis: {
      auditScoreAvg: null,
      auditScoreMin: null,
      auditScoreMax: null
    },
    recentAudits: [],
    openNonConformities: [],
    overdueActions: [],
    criticalIncidents: [],
    priorityAlerts: [],
    export: {
      documentTitle: siteIdNormalized
        ? 'Synthèse QHSE — périmètre site'
        : 'Synthèse QHSE consolidée',
      schemaVersion: 1,
      sectionsOrder: [
        'counts',
        'kpis',
        'priorityAlerts',
        'criticalIncidents',
        'overdueActions',
        'openNonConformities',
        'recentAudits'
      ]
    }
  };
}

/**
 * Synthèse consolidée pour pilotage QHSE / direction.
 * @param {string | null | undefined} tenantId
 * @param {string | null} [siteId] — filtre optionnel dans le tenant
 * @param {{ emptyIfNoTenant?: boolean, periodDays?: number }} [options]
 */
export async function getReportingSummary(tenantId, siteId = null, options = {}) {
  const emptyIfNoTenant = options.emptyIfNoTenant === true;
  const rawDays = Number(options.periodDays);
  const periodDays =
    Number.isFinite(rawDays) && rawDays > 0 && rawDays <= 366
      ? Math.floor(rawDays)
      : DEFAULT_PERIOD_DAYS;

  const tid = normalizeTenantId(tenantId);
  if (!tid) {
    if (emptyIfNoTenant) {
      return buildEmptyReportingSummary(normalizeSiteId(siteId));
    }
    const err = new Error(TENANT_CONTEXT_REQUIRED_MESSAGE);
    err.statusCode = 403;
    throw err;
  }

  const sid = normalizeSiteId(siteId);
  const baseWhere = reportingSummaryWhere(tid, siteId);

  const sincePeriod = new Date();
  sincePeriod.setDate(sincePeriod.getDate() - periodDays);

  const [
    incidentsTotal,
    incidentsLast30Days,
    nonConformitiesTotal,
    nonConformitiesOpen,
    actionsTotal,
    actionsOverdue,
    auditsTotal,
    auditAggregate,
    recentAudits,
    nonConformityRows,
    overdueActionsRows,
    recentIncidents
  ] = await Promise.all([
    prisma.incident.count({ where: baseWhere }),
    prisma.incident.count({
      where: {
        ...baseWhere,
        createdAt: { gte: sincePeriod }
      }
    }),
    prisma.nonConformity.count({ where: baseWhere }),
    countNonConformitiesOpenForReporting(tid, siteId),
    prisma.action.count({ where: baseWhere }),
    countActionsOverdueForReporting(tid, siteId),
    prisma.audit.count({ where: baseWhere }),
    prisma.audit.aggregate({
      where: baseWhere,
      _avg: { score: true },
      _max: { score: true },
      _min: { score: true }
    }),
    prisma.audit.findMany({
      where: baseWhere,
      select: {
        ref: true,
        site: true,
        score: true,
        status: true,
        createdAt: true
      },
      orderBy: { createdAt: 'desc' },
      take: LIST_AUDITS
    }),
    prisma.nonConformity.findMany({
      where: baseWhere,
      select: {
        id: true,
        title: true,
        detail: true,
        status: true,
        auditRef: true,
        createdAt: true
      },
      orderBy: { createdAt: 'desc' },
      take: 500
    }),
    prisma.action
      .findMany({
        where: baseWhere,
        select: {
          title: true,
          detail: true,
          status: true,
          owner: true,
          dueDate: true,
          createdAt: true
        },
        take: 800
      })
      .then((rows) =>
        rows
          .filter(isActionOverdueDashboardRow)
          .sort(
            (a, b) =>
              (a.dueDate ? new Date(a.dueDate).getTime() : a.createdAt.getTime()) -
              (b.dueDate ? new Date(b.dueDate).getTime() : b.createdAt.getTime())
          )
          .slice(0, LIST_ACTIONS)
      ),
    prisma.incident.findMany({
      where: baseWhere,
      select: {
        ref: true,
        type: true,
        site: true,
        severity: true,
        status: true,
        createdAt: true
      },
      orderBy: { createdAt: 'desc' },
      take: RECENT_INCIDENT_SCAN
    })
  ]);

  const openNonConformities = nonConformityRows.filter((r) => isNcOpen(r.status));

  const overdueActions = (Array.isArray(overdueActionsRows) ? overdueActionsRows : []).map(
    (row) => ({
      title: row.title,
      detail: row.detail,
      status: row.status,
      owner: row.owner,
      dueDate: row.dueDate ? new Date(row.dueDate).toISOString() : null,
      createdAt: new Date(row.createdAt).toISOString()
    })
  );

  const criticalIncidents = recentIncidents.filter(
    (row) =>
      includesInsensitive(row.severity, 'critique') && isIncidentLikelyOpen(row.status)
  );

  const incidentsCriticalOpen = criticalIncidents.length;

  const criticalIncidentsList = criticalIncidents.slice(0, LIST_CRITICAL_INCIDENTS).map((row) => ({
    ref: row.ref,
    type: row.type,
    site: row.site,
    status: row.status,
    createdAt: row.createdAt.toISOString()
  }));

  const openNcSample = openNonConformities.slice(0, LIST_NC).map((row) => ({
    id: row.id,
    title: row.title,
    detail: row.detail,
    status: row.status,
    auditRef: row.auditRef,
    createdAt: row.createdAt.toISOString()
  }));

  const avg = auditAggregate._avg.score;
  const auditScoreAvg = avg != null && !Number.isNaN(avg) ? Math.round(avg * 10) / 10 : null;

  const recentAuditsOut = recentAudits.map((a) => ({
    ref: a.ref,
    site: a.site,
    score: a.score,
    status: a.status,
    createdAt: a.createdAt.toISOString()
  }));

  const priorityAlerts = buildPriorityAlerts({
    incidentsCriticalOpen,
    actionsOverdue,
    nonConformitiesOpen,
    auditScoreAvg,
    auditsTotal,
    incidentsLast30Days
  });

  const generatedAt = new Date().toISOString();

  return {
    generatedAt,
    siteId: sid,
    counts: {
      incidentsTotal,
      incidentsLast30Days,
      incidentsCriticalOpen,
      nonConformitiesTotal,
      nonConformitiesOpen,
      actionsTotal,
      actionsOverdue,
      auditsTotal
    },
    kpis: {
      auditScoreAvg,
      auditScoreMin: auditAggregate._min.score,
      auditScoreMax: auditAggregate._max.score
    },
    recentAudits: recentAuditsOut,
    openNonConformities: openNcSample,
    overdueActions,
    criticalIncidents: criticalIncidentsList,
    priorityAlerts,
    export: {
      documentTitle: sid ? 'Synthèse QHSE — périmètre site' : 'Synthèse QHSE consolidée',
      schemaVersion: 1,
      sectionsOrder: [
        'counts',
        'kpis',
        'priorityAlerts',
        'criticalIncidents',
        'overdueActions',
        'openNonConformities',
        'recentAudits'
      ]
    }
  };
}
