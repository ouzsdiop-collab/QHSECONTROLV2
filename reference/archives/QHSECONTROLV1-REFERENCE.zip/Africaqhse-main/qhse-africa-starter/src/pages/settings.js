import { showToast } from '../components/toast.js';
import { ensureSettingsPageStyles } from '../components/settingsPageStyles.js';
import { ensureQhsePilotageStyles } from '../components/qhsePilotageStyles.js';
import {
  getSessionUser,
  getAuthToken,
  getActiveTenant,
  getSessionTenants,
  switchActiveTenant
} from '../data/sessionUser.js';
import { canAccessNavPage } from '../utils/permissionsUi.js';
import {
  SENSITIVE_ACCESS_ACTION_META,
  loadSensitiveAccessConfig,
  saveSensitiveAccessConfig,
  loadSensitiveAccessPin,
  saveSensitiveAccessPin,
  clearSensitiveAccessSessionCache
} from '../data/sensitiveAccessConfig.js';
import {
  isDemoMode,
  isDemoModeAllowed,
  setDemoMode,
  resetDemoPresentation
} from '../services/demoMode.service.js';
import { qhseFetch } from '../utils/qhseFetch.js';
import { validatePasswordPolicy } from '../utils/passwordPolicy.js';

const LS_ALERTS = 'qhse_cfg_alerts_v1';
const LS_NOTIF = 'qhse_cfg_notif_v1';
const LS_EXPORT = 'qhse_cfg_export_pdf_v1';
const LS_IA = 'qhse_cfg_ia_modules_v1';
const LS_CYCLE = 'qhse_cfg_control_cycle_v1';
const LS_CYCLE_USAGE = 'qhse_cfg_cycle_usage_v1';

/** @returns {Record<string, unknown>} */
function loadJson(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return { ...fallback };
    const o = JSON.parse(raw);
    return o && typeof o === 'object' ? o : { ...fallback };
  } catch {
    return { ...fallback };
  }
}

function saveJson(key, data) {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch {
    showToast('Enregistrement local impossible (navigateur).', 'warning');
  }
}

const DEFAULT_ALERTS = [
  {
    id: 'al-1',
    name: 'Actions en retard',
    condition: 'Échéance dépassée > 7 j (paramétrage serveur à brancher)',
    level: 'warning',
    channel: 'app',
    on: true
  },
  {
    id: 'al-2',
    name: 'Incident critique ouvert',
    condition: 'Gravité critique et statut non clos',
    level: 'critique',
    channel: 'email',
    on: true
  },
  {
    id: 'al-3',
    name: 'Nouvelle non-conformité majeure',
    condition: 'NC créée depuis audit : classement majeur',
    level: 'critique',
    channel: 'app',
    on: false
  },
  {
    id: 'al-4',
    name: 'Rapport périodique PDF',
    condition: 'Synthèse hebdomadaire (planification serveur)',
    level: 'info',
    channel: 'pdf',
    on: false
  }
];

const STATUS_OPTIONS = [
  ['a_controler', 'À contrôler'],
  ['a_corriger', 'À corriger'],
  ['corrige', 'Corrigé'],
  ['a_verifier', 'À vérifier'],
  ['valide', 'Validé'],
  ['rejete', 'Rejeté']
];

/** @type {{ key: string; title: string; hint: string }[]} */
const USAGE_FLOW_ROWS = [
  {
    key: 'aiExtract',
    title: 'Extraction assistée (document)',
    hint: 'Exemple : sortie structurée à valider avant publication au référentiel.'
  },
  {
    key: 'iaSuggest',
    title: 'Suggestion assistée',
    hint: 'Exemple : proposition à corriger ou reformuler avant application.'
  },
  {
    key: 'importDoc',
    title: 'Import documentaire',
    hint: 'Exemple : fiche importée. Contrôle puis validation après correction si besoin.'
  },
  {
    key: 'autoExtract',
    title: 'Extraction automatique',
    hint: 'Exemple : champs pré-remplis. Passage souvent en « à vérifier ».'
  },
  {
    key: 'ecartNc',
    title: 'Écart / non-conformité',
    hint: 'Exemple : constat. Typiquement « à corriger » avec preuves attendues.'
  },
  {
    key: 'audit',
    title: 'Audits & constats',
    hint: 'Exemple : preuves et réponses. Contrôle humain avant clôture.'
  },
  {
    key: 'preuve',
    title: 'Preuve / document à vérifier',
    hint: 'Exemple : pièce jointe. État « à vérifier » jusqu’à visa.'
  }
];

const DEFAULT_CYCLE_USAGE = {
  aiExtract: { defaultStatus: 'a_controler', humanRequired: true },
  iaSuggest: { defaultStatus: 'a_corriger', humanRequired: true },
  importDoc: { defaultStatus: 'a_controler', humanRequired: true },
  autoExtract: { defaultStatus: 'a_verifier', humanRequired: true },
  ecartNc: { defaultStatus: 'a_corriger', humanRequired: true },
  audit: { defaultStatus: 'a_controler', humanRequired: true },
  preuve: { defaultStatus: 'a_verifier', humanRequired: true }
};

function normalizeCycleUsage(raw) {
  const out = { ...DEFAULT_CYCLE_USAGE };
  USAGE_FLOW_ROWS.forEach(({ key }) => {
    const cur = raw && typeof raw[key] === 'object' ? raw[key] : {};
    out[key] = {
      defaultStatus:
        typeof cur.defaultStatus === 'string' ? cur.defaultStatus : DEFAULT_CYCLE_USAGE[key].defaultStatus,
      humanRequired:
        typeof cur.humanRequired === 'boolean' ? cur.humanRequired : DEFAULT_CYCLE_USAGE[key].humanRequired
    };
  });
  return out;
}

function levelClass(level) {
  if (level === 'critique') return 'settings-tag--critique';
  if (level === 'warning') return 'settings-tag--warning';
  return 'settings-tag--info';
}

function channelLabel(c) {
  if (c === 'email') return 'E-mail';
  if (c === 'pdf') return 'PDF';
  return 'Application';
}

/**
 * @param {{ id: string; name: string; condition: string; level: string; channel: string; on: boolean }[]} alerts
 * @param {(next: typeof alerts) => void} onChange
 */
function renderAlertList(host, alerts, onChange) {
  host.replaceChildren();
  alerts.forEach((a) => {
    const row = document.createElement('div');
    row.className = 'settings-alert-row';
    const main = document.createElement('div');
    main.className = 'settings-alert-main';
    const name = document.createElement('p');
    name.className = 'settings-alert-name';
    name.textContent = a.name;
    const meta = document.createElement('p');
    meta.className = 'settings-alert-meta';
    meta.textContent = a.condition;
    const tags = document.createElement('div');
    tags.className = 'settings-alert-tags';
    const t1 = document.createElement('span');
    t1.className = `settings-tag ${levelClass(a.level)}`;
    t1.textContent = a.level;
    const t2 = document.createElement('span');
    t2.className = 'settings-tag';
    t2.textContent = channelLabel(a.channel);
    tags.append(t1, t2);
    main.append(name, meta, tags);

    const swWrap = document.createElement('div');
    swWrap.className = 'settings-switch-wrap';
    const swLabel = document.createElement('span');
    swLabel.className = 'settings-switch-label';
    swLabel.textContent = a.on ? 'Actif' : 'Inactif';
    const sw = document.createElement('button');
    sw.type = 'button';
    sw.className = 'settings-switch';
    sw.setAttribute('role', 'switch');
    sw.setAttribute('aria-checked', a.on ? 'true' : 'false');
    sw.setAttribute('aria-label', `Alerte ${a.name}`);
    sw.addEventListener('click', () => {
      const next = alerts.map((x) =>
        x.id === a.id ? { ...x, on: !x.on } : x
      );
      onChange(next);
    });
    swWrap.append(swLabel, sw);
    row.append(main, swWrap);
    host.append(row);
  });
}

function goHash(pageId) {
  window.location.hash = pageId;
}

const SS_IMPORT_INTENT = 'qhse_import_intent_v1';

function goImportWithIntent(intent) {
  try {
    sessionStorage.setItem(SS_IMPORT_INTENT, intent);
  } catch {
    /* ignore */
  }
  goHash('imports');
}

/** Import générique : nettoie l’intention contextuelle pour éviter une bannière obsolète. */
function goHashImportsWithoutIntent() {
  try {
    sessionStorage.removeItem(SS_IMPORT_INTENT);
  } catch {
    /* ignore */
  }
  goHash('imports');
}

function scrollToSettingsSection(id) {
  const el = document.getElementById(id);
  if (el && typeof el.scrollIntoView === 'function') {
    el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}

export function renderSettings() {
  ensureSettingsPageStyles();
  ensureQhsePilotageStyles();

  async function readFailedApiResponse(res) {
    try {
      const j = await res.json();
      const body = j && typeof j === 'object' ? j : {};
      const message =
        typeof body.error === 'string' && body.error.trim() ? body.error.trim() : '';
      return { body, message };
    } catch {
      return { body: {}, message: '' };
    }
  }

  const sessionUserEarly = getSessionUser();
  const isAdminUser =
    String(sessionUserEarly?.role || '').toUpperCase() === 'ADMIN';

  const page = document.createElement('section');
  page.className = 'page-stack page-stack--premium-saas settings-page settings-page--hq';

  const hero = document.createElement('article');
  hero.className = 'content-card card-soft settings-hero';
  hero.innerHTML = `
    <div class="settings-hero-premium">
      <div class="settings-hero-premium__top">
        <p class="settings-hero-premium__eyebrow">Espace configuration</p>
        <h1 class="settings-hero-premium__title">Paramètres &amp; pilotage QHSE</h1>
        <p class="settings-hero-premium__lead">
          Cadre central pour l’organisation, la veille, les notifications, les exports, les référentiels,
          la gouvernance IA et le cycle de maîtrise (détection → clôture). Les réglages ci-dessous sont
          enregistrés localement dans le navigateur jusqu’à branchement sur une API paramètres.
        </p>
        <div class="settings-hero-premium__meta" aria-hidden="true">
          <span class="settings-hero-chip">Piloter · Agir · Contrôler</span>
          <span class="settings-hero-chip">Corriger · Prouver · Décider</span>
          <span class="settings-hero-chip">IA sous validation humaine</span>
        </div>
        <div class="settings-hero-premium__meta settings-hero-premium__meta--note" aria-hidden="true">
          <span class="settings-hero-chip settings-hero-chip--note">Persistance locale (navigateur)</span>
          <span class="settings-hero-chip settings-hero-chip--note">Modules &amp; routes existants préservés</span>
        </div>
      </div>
      <nav class="settings-toc" aria-label="Accès aux sections"></nav>
    </div>
  `;
  const tocNav = hero.querySelector('.settings-toc');
  const showDemo = isDemoModeAllowed();
  const tocSpec = [
    ...(showDemo
      ? [{ id: 'settings-anchor-demo', label: 'Exploration hors API' }]
      : []),
    { id: 'settings-anchor-org', label: 'Organisation' },
    { id: 'settings-anchor-alerts', label: 'Alertes' },
    { id: 'settings-anchor-notif', label: 'Notifications' },
    ...(isAdminUser
      ? [{ id: 'settings-anchor-email-notif', label: 'Notifications email' }]
      : []),
    { id: 'settings-anchor-exports', label: 'Exportations' },
    { id: 'settings-anchor-security-access', label: 'Sécurité & accès' },
    { id: 'settings-anchor-ref', label: 'Référentiels' },
    { id: 'settings-anchor-ia', label: 'IA' },
    { id: 'settings-anchor-cycle', label: 'Maîtrise' },
    { id: 'settings-anchor-help', label: 'Aide & support' }
  ];
  tocSpec.forEach(({ id, label }) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'settings-toc__btn';
    b.textContent = label;
    b.addEventListener('click', () => scrollToSettingsSection(id));
    tocNav?.append(b);
  });

  /** @type {HTMLElement | null} */
  let secDemo = null;
  if (showDemo) {
    secDemo = document.createElement('section');
    secDemo.className = 'settings-section';
    secDemo.id = 'settings-anchor-demo';
    secDemo.setAttribute('aria-labelledby', 'settings-demo-title');
    secDemo.innerHTML = `
    <header class="settings-section__head">
      <p class="settings-section__kicker">Présentation</p>
      <h4 class="settings-section__title" id="settings-demo-title">Exploration hors API</h4>
      <p class="settings-section__lead">
        Fournit des <strong>données d’illustration</strong> cohérentes dans le navigateur (incidents, actions, audits, non-conformités, notifications)
        pour formation ou pré-production lorsque l’API n’est pas utilisée ou seulement partiellement disponible.
        En build <strong>production</strong>, cette section n’apparaît que si le déploiement définit <code>VITE_ALLOW_DEMO_MODE=true</code>.
        Les requêtes passent par le même client que l’app : en mode exploration actif, les routes mockées ne contactent pas le backend.
      </p>
    </header>
    <div class="settings-demo-card content-card card-soft">
      <div class="settings-demo-row">
        <label class="settings-demo-switch-label">
          <input type="checkbox" class="settings-demo-toggle" data-demo-toggle />
          <span>Activer les données d’exploration locales</span>
        </label>
      </div>
      <p class="settings-demo-hint">
        Après activation ou désactivation, la page se recharge pour rafraîchir tableaux de bord, listes et notifications.
      </p>
      <div class="settings-demo-actions">
        <button type="button" class="btn btn-secondary" data-demo-reset>Réinitialiser le scénario</button>
      </div>
      <p class="settings-demo-foot">
        « Réinitialiser » efface les ajustements locaux (Kanban, incidents, lectures de notifications) tout en conservant le mode exploration activé ou non.
      </p>
    </div>
  `;
    const demoToggle = secDemo.querySelector('[data-demo-toggle]');
    const demoReset = secDemo.querySelector('[data-demo-reset]');
    if (demoToggle instanceof HTMLInputElement) {
      demoToggle.checked = isDemoMode();
      demoToggle.addEventListener('change', () => {
        setDemoMode(demoToggle.checked);
        showToast(
          demoToggle.checked
            ? 'Données d’exploration activées. Rechargement…'
            : 'Données d’exploration désactivées. Rechargement…',
          'info'
        );
        window.setTimeout(() => window.location.reload(), 120);
      });
    }
    if (demoReset) {
      demoReset.addEventListener('click', () => {
        resetDemoPresentation();
        showToast('Scénario réinitialisé. Rechargement…', 'success');
        window.setTimeout(() => window.location.reload(), 120);
      });
    }
  }

  /* Organisation */
  const secA = document.createElement('section');
  secA.className = 'settings-section';
  secA.id = 'settings-anchor-org';
  secA.setAttribute('aria-labelledby', 'settings-org-title');
  secA.innerHTML = `
    <header class="settings-section__head">
      <p class="settings-section__kicker">A · Organisation &amp; sites</p>
      <h4 class="settings-section__title" id="settings-org-title">Organisation &amp; sites</h4>
      <p class="settings-section__lead">
        Référentiel des sites et import documentaire : mêmes écrans, mêmes routes (#sites, #imports) et mêmes droits.
        Le périmètre actif reste piloté depuis le pied de menu latéral.
      </p>
    </header>
    <div class="settings-tenant-switch" data-settings-tenant-switch style="display:none"></div>
    <div class="settings-grid-2" data-settings-org-grid></div>
    <div class="settings-org-context-bar" data-settings-org-context></div>
  `;
  const tenantSwitchHost = secA.querySelector('[data-settings-tenant-switch]');
  if (tenantSwitchHost && getAuthToken()) {
    const tenants = getSessionTenants();
    const active = getActiveTenant();
    if (active && tenants.length > 1) {
      tenantSwitchHost.style.display = 'block';
      tenantSwitchHost.className = 'settings-tenant-switch content-card card-soft';
      tenantSwitchHost.style.marginBottom = '16px';
      tenantSwitchHost.innerHTML = `
        <p class="settings-section__kicker" style="margin:0 0 8px">Compte connecté</p>
        <p class="settings-demo-hint" style="margin:0 0 12px">
          Organisation active : <strong data-tenant-active-name></strong>
          <span class="dashboard-muted-lead"> Plusieurs organisations sont disponibles pour votre profil.</span>
        </p>
        <label class="field field-full">
          <span>Changer d’organisation</span>
          <select class="control-input settings-tenant-select"></select>
        </label>
        <button type="button" class="btn btn-primary settings-tenant-apply" style="margin-top:10px">Appliquer</button>
      `;
      const nameEl = tenantSwitchHost.querySelector('[data-tenant-active-name]');
      if (nameEl) nameEl.textContent = active.name || active.slug;
      const sel = tenantSwitchHost.querySelector('.settings-tenant-select');
      if (sel instanceof HTMLSelectElement) {
        for (const t of tenants) {
          const opt = document.createElement('option');
          opt.value = t.slug;
          opt.textContent = t.name || t.slug;
          if (t.slug === active.slug) opt.selected = true;
          sel.appendChild(opt);
        }
      }
      const applyBtn = tenantSwitchHost.querySelector('.settings-tenant-apply');
      applyBtn?.addEventListener('click', async () => {
        const slug = sel instanceof HTMLSelectElement ? sel.value.trim() : '';
        if (!slug || slug === active.slug) {
          showToast('Sélectionnez une autre organisation.', 'info');
          return;
        }
        const r = await switchActiveTenant(slug);
        if (r.ok) {
          showToast('Organisation mise à jour. Rechargement…', 'success');
          window.setTimeout(() => window.location.reload(), 400);
        } else {
          showToast('Changement impossible. Reconnectez-vous si besoin.', 'error');
        }
      });
    }
  }
  const orgGrid = secA.querySelector('[data-settings-org-grid]');
  const cardSites = document.createElement('div');
  cardSites.className = 'settings-link-card';
  cardSites.innerHTML = `
    <span class="settings-link-card__label">Référentiel</span>
    <h5 class="settings-link-card__title">Sites &amp; périmètres</h5>
    <p class="settings-link-card__desc">Sites, codes et rattachement des modules opérationnels.</p>
  `;
  const btnSites = document.createElement('button');
  btnSites.type = 'button';
  btnSites.className = 'btn btn-primary';
  btnSites.textContent = 'Ouvrir Sites';
  btnSites.addEventListener('click', () => goHash('sites'));
  cardSites.append(btnSites);
  const suNav = getSessionUser();
  if (suNav && !canAccessNavPage(suNav.role, 'sites')) {
    btnSites.disabled = true;
    btnSites.title = 'Accès réservé pour votre profil';
    btnSites.style.opacity = '0.55';
  }

  const cardImports = document.createElement('div');
  cardImports.className = 'settings-link-card';
  cardImports.innerHTML = `
    <span class="settings-link-card__label">Documents</span>
    <h5 class="settings-link-card__title">Import de documents</h5>
    <p class="settings-link-card__desc">Chargement, pré-analyse et brouillon. Validation sur le module cible.</p>
  `;
  const btnImports = document.createElement('button');
  btnImports.type = 'button';
  btnImports.className = 'btn btn-secondary';
  btnImports.textContent = 'Ouvrir Import';
  btnImports.addEventListener('click', () => goHashImportsWithoutIntent());
  cardImports.append(btnImports);
  if (suNav && !canAccessNavPage(suNav.role, 'imports')) {
    btnImports.disabled = true;
    btnImports.title = 'Accès réservé pour votre profil';
    btnImports.style.opacity = '0.55';
  }
  if (orgGrid) orgGrid.append(cardSites, cardImports);

  const orgCtx = secA.querySelector('[data-settings-org-context]');
  if (orgCtx) {
    const cap = document.createElement('p');
    cap.className = 'settings-org-context-bar__cap';
    cap.textContent = 'Imports contextuels (préparation)';
    const actions = document.createElement('div');
    actions.className = 'settings-org-context-bar__actions';
    function mkIntentBtn(label, intent) {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'btn btn-secondary';
      b.textContent = label;
      b.addEventListener('click', () => goImportWithIntent(intent));
      if (suNav && !canAccessNavPage(suNav.role, 'imports')) {
        b.disabled = true;
        b.title = 'Accès réservé pour votre profil';
        b.style.opacity = '0.55';
      }
      return b;
    }
    actions.append(
      mkIntentBtn('Import orienté risques', 'risks'),
      mkIntentBtn('Import FDS / produits', 'fds'),
      mkIntentBtn('Import ISO / exigences', 'iso')
    );
    orgCtx.append(cap, actions);
  }

  /* Alertes */
  const savedAlerts = loadJson(LS_ALERTS, {});
  let alertsState = Array.isArray(savedAlerts.list) && savedAlerts.list.length ? savedAlerts.list : [...DEFAULT_ALERTS];

  const secB = document.createElement('section');
  secB.className = 'settings-section';
  secB.id = 'settings-anchor-alerts';
  secB.innerHTML = `
    <header class="settings-section__head">
      <p class="settings-section__kicker">B · Règles d’alerte</p>
      <h4 class="settings-section__title">Règles d’alerte</h4>
      <p class="settings-section__lead">
        Règles et niveaux de criticité affichés ici. L’évaluation réelle des conditions restera côté serveur.
      </p>
    </header>
    <div class="settings-alert-list" data-settings-alerts></div>
    <div class="settings-actions-bar">
      <button type="button" class="btn btn-secondary" data-settings-add-alert>Créer une alerte</button>
    </div>
  `;
  const alertsHost = secB.querySelector('[data-settings-alerts]');
  function persistAlerts() {
    saveJson(LS_ALERTS, { list: alertsState });
  }
  function redrawAlerts() {
    if (!alertsHost) return;
    renderAlertList(alertsHost, alertsState, (next) => {
      alertsState = next;
      persistAlerts();
      redrawAlerts();
    });
  }
  redrawAlerts();
  secB.querySelector('[data-settings-add-alert]')?.addEventListener('click', () => {
    const id = `al-${Date.now()}`;
    alertsState = [
      ...alertsState,
      {
        id,
        name: 'Nouvelle alerte',
        condition: 'Condition à définir (placeholder)',
        level: 'info',
        channel: 'app',
        on: true
      }
    ];
    persistAlerts();
    redrawAlerts();
    showToast('Alerte ajoutée (locale). Branchez la création sur l’API.', 'info');
  });

  /* Notifications */
  let notif = {
    minLevel: 'warning',
    digest: true,
    push: false,
    ...loadJson(LS_NOTIF, {})
  };
  const secC = document.createElement('section');
  secC.className = 'settings-section';
  secC.id = 'settings-anchor-notif';
  secC.innerHTML = `
    <header class="settings-section__head">
      <p class="settings-section__kicker">C · Notifications</p>
      <h4 class="settings-section__title">Notifications</h4>
      <p class="settings-section__lead">
        Filtres d’affichage dans l’application (configuration locale). Le centre de notifications existant n’est pas modifié.
      </p>
    </header>
    <div class="settings-prefs-grid" data-settings-notif></div>
  `;
  const notifHost = secC.querySelector('[data-settings-notif]');
  function buildNotifRow(label, key, type, options) {
    const row = document.createElement('div');
    row.className = 'settings-pref-row';
    const span = document.createElement('span');
    span.textContent = label;
    row.append(span);
    if (type === 'select') {
      const sel = document.createElement('select');
      sel.className = 'control-input';
      options.forEach(([v, t]) => {
        const o = document.createElement('option');
        o.value = v;
        o.textContent = t;
        sel.append(o);
      });
      sel.value = notif[key] || options[0][0];
      sel.addEventListener('change', () => {
        notif = { ...notif, [key]: sel.value };
        saveJson(LS_NOTIF, notif);
        showToast('Préférence enregistrée (navigateur).', 'info');
      });
      row.append(sel);
    } else {
      const sw = document.createElement('button');
      sw.type = 'button';
      sw.className = 'settings-switch';
      sw.setAttribute('role', 'switch');
      sw.setAttribute(
        'aria-label',
        `${label} : ${notif[key] ? 'activé' : 'désactivé'}`
      );
      sw.setAttribute('aria-checked', !!notif[key] ? 'true' : 'false');
      sw.addEventListener('click', () => {
        const next = !notif[key];
        notif = { ...notif, [key]: next };
        sw.setAttribute('aria-checked', next ? 'true' : 'false');
        sw.setAttribute(
          'aria-label',
          `${label} : ${next ? 'activé' : 'désactivé'}`
        );
        saveJson(LS_NOTIF, notif);
        showToast('Préférence enregistrée (navigateur).', 'info');
      });
      row.append(sw);
    }
    return row;
  }
  notifHost.append(
    buildNotifRow('Niveau minimum affiché', 'minLevel', 'select', [
      ['info', 'Info et plus'],
      ['warning', 'Avertissement et plus'],
      ['critique', 'Critique uniquement']
    ]),
    buildNotifRow('Digest quotidien (e-mail)', 'digest', 'toggle'),
    buildNotifRow('Notifications push navigateur', 'push', 'toggle')
  );

  /** @type {HTMLElement | null} */
  let secEmail = null;
  if (isAdminUser) {
    secEmail = document.createElement('section');
    secEmail.className = 'settings-section';
    secEmail.id = 'settings-anchor-email-notif';
    secEmail.innerHTML = `
    <header class="settings-section__head">
      <p class="settings-section__kicker">C2 · Courriel serveur</p>
      <h4 class="settings-section__title">Notifications email</h4>
      <p class="settings-section__lead">
        Configuration SMTP via les variables d’environnement du backend (<code>backend/.env</code>).
        Les secrets ne sont jamais renvoyés au navigateur. Les interrupteurs ci-dessous pilotent l’envoi côté API (mémoire processus jusqu’à redémarrage).
      </p>
    </header>
    <div class="content-card card-soft" style="padding:16px;margin-bottom:16px">
      <p class="settings-alert-meta" data-email-status>Chargement du statut SMTP…</p>
      <div class="settings-grid-2" style="margin-top:12px">
        <label class="field">
          <span>SMTP_HOST</span>
          <input type="text" class="control-input" readonly placeholder="défini dans .env (non affiché)" data-email-ph />
        </label>
        <label class="field">
          <span>SMTP_PORT</span>
          <input type="text" class="control-input" readonly value="587" data-email-port-hint />
        </label>
        <label class="field">
          <span>SMTP_USER</span>
          <input type="text" class="control-input" readonly placeholder="fourni par votre hébergeur mail" />
        </label>
        <label class="field">
          <span>SMTP_PASS</span>
          <input type="password" class="control-input" readonly placeholder="jamais exposé au client" />
        </label>
        <label class="field">
          <span>SMTP_FROM / EMAIL_FROM</span>
          <input type="text" class="control-input" readonly placeholder="QHSE Control &lt;noreply@…&gt;" data-email-from-masked />
        </label>
        <label class="field">
          <span>Resend (optionnel)</span>
          <input type="text" class="control-input" readonly placeholder="Clé API : uniquement si vous branchez Resend côté serveur" data-email-resend-note />
        </label>
      </div>
      <p class="settings-demo-hint" style="margin-top:12px">
        Avec <strong>Resend</strong>, utilisez en général l’hôte SMTP <code>smtp.resend.com</code>, port <code>465</code> ou <code>587</code>, et les identifiants fournis par le tableau de bord Resend.
      </p>
      <div class="settings-actions-bar" style="margin-top:12px">
        <button type="button" class="btn btn-primary" data-email-test>Envoyer email test</button>
      </div>
    </div>
    <div class="settings-prefs-grid" data-email-toggles></div>
  `;
    const emailStatusEl = secEmail.querySelector('[data-email-status]');
    const fromMaskedEl = secEmail.querySelector('[data-email-from-masked]');
    const togglesHost = secEmail.querySelector('[data-email-toggles]');
    /** @type {{ criticalIncidents?: boolean, actionOverdue?: boolean, auditScheduled?: boolean, weeklySummary?: boolean }} */
    let emailPrefs = {};

    function mkEmailToggle(label, key) {
      const row = document.createElement('div');
      row.className = 'settings-pref-row';
      const span = document.createElement('span');
      span.textContent = label;
      row.append(span);
      const sw = document.createElement('button');
      sw.type = 'button';
      sw.className = 'settings-switch';
      sw.setAttribute('role', 'switch');
      const on = () => !!emailPrefs[key];
      const sync = () => {
        sw.setAttribute('aria-checked', on() ? 'true' : 'false');
        sw.setAttribute('aria-label', `${label} : ${on() ? 'activé' : 'désactivé'}`);
      };
      sync();
      sw.addEventListener('click', async () => {
        const next = !on();
        try {
          const r = await qhseFetch('/api/settings/email-notifications', {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ [key]: next })
          });
          if (!r.ok) {
            const { message } = await readFailedApiResponse(r);
            showToast(message || 'Mise à jour impossible.', 'error');
            return;
          }
          const j = await r.json().catch(() => ({}));
          if (j.prefs && typeof j.prefs === 'object') emailPrefs = { ...j.prefs };
          sync();
          showToast('Préférence enregistrée.', 'info');
        } catch {
          showToast('Erreur réseau.', 'error');
        }
      });
      row.append(sw);
      return row;
    }

    async function refreshEmailPanel() {
      try {
        const r = await qhseFetch('/api/settings/email-notifications');
        if (!r.ok) {
          if (emailStatusEl) {
            emailStatusEl.textContent =
              'Impossible de charger le statut (vérifiez la connexion et le rôle ADMIN).';
          }
          return;
        }
        const j = await r.json();
        if (emailStatusEl) {
          emailStatusEl.textContent = j.smtpConfigured
            ? `SMTP prêt · expéditeur : ${j.fromMasked || '(masqué)'}`
            : 'SMTP non configuré : renseignez SMTP_HOST et SMTP_FROM (ou EMAIL_FROM) sur le serveur.';
        }
        if (fromMaskedEl && j.fromMasked) fromMaskedEl.value = String(j.fromMasked);
        if (j.prefs && typeof j.prefs === 'object') {
          emailPrefs = { ...j.prefs };
          if (togglesHost) {
            togglesHost.replaceChildren(
              mkEmailToggle('Alertes incidents critiques', 'criticalIncidents'),
              mkEmailToggle('Rappels actions en retard', 'actionOverdue'),
              mkEmailToggle('Convocations audit planifié', 'auditScheduled'),
              mkEmailToggle('Résumé hebdomadaire (lundi 8h)', 'weeklySummary')
            );
          }
        }
      } catch {
        if (emailStatusEl) emailStatusEl.textContent = 'Erreur lors du chargement.';
      }
    }

    secEmail.querySelector('[data-email-test]')?.addEventListener('click', async () => {
      try {
        const r = await qhseFetch('/api/settings/email-test', { method: 'POST' });
        if (!r.ok) {
          const { message } = await readFailedApiResponse(r);
          showToast(message || `Échec (HTTP ${r.status}).`, 'error');
          return;
        }
        showToast('E-mail de test envoyé. Vérifiez votre boîte (et les spams).', 'success');
      } catch {
        showToast('Envoi test impossible.', 'error');
      }
    });

    void refreshEmailPanel();
  }

  /* Exports PDF */
  let exportPdf = loadJson(LS_EXPORT, {
    audits: true,
    nc: true,
    actions: true,
    incidents: true,
    iso: false
  });
  const secD = document.createElement('section');
  secD.className = 'settings-section';
  secD.id = 'settings-anchor-exports';
  secD.innerHTML = `
    <header class="settings-section__head">
      <p class="settings-section__kicker">D · Exports &amp; rapports</p>
      <h4 class="settings-section__title">Exports &amp; rapports PDF</h4>
      <p class="settings-section__lead">
        Chapitres inclus dans les futurs modèles de synthèse (UI seule ; génération réelle côté serveur).
      </p>
    </header>
    <div class="settings-check-grid" data-settings-export></div>
  `;
  const exportHost = secD.querySelector('[data-settings-export]');
  const exportDefs = [
    ['audits', 'Audits & constats'],
    ['nc', 'Non-conformités'],
    ['actions', 'Plan d’actions'],
    ['incidents', 'Incidents'],
    ['iso', 'Synthèse ISO / exigences']
  ];
  exportDefs.forEach(([key, lab]) => {
    const labEl = document.createElement('label');
    labEl.className = 'settings-check';
    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.checked = !!exportPdf[key];
    cb.addEventListener('change', () => {
      exportPdf = { ...exportPdf, [key]: cb.checked };
      saveJson(LS_EXPORT, exportPdf);
    });
    const txt = document.createElement('span');
    txt.textContent = lab;
    labEl.append(cb, txt);
    exportHost.append(labEl);
  });

  /* Sécurité & accès renforcé (code 6 chiffres, session locale) */
  let sensitiveCfg = loadSensitiveAccessConfig();
  const secH = document.createElement('section');
  secH.className = 'settings-section settings-section--sensitive-access';
  secH.id = 'settings-anchor-security-access';
  secH.innerHTML = `
    <header class="settings-section__head">
      <p class="settings-section__kicker">H · Sécurité &amp; accès</p>
      <h4 class="settings-section__title">Code de vérification (accès renforcé)</h4>
      <p class="settings-section__lead">
        Optionnel : code à 6 chiffres sur les actions que vous cochez. Par défaut : une demande par session navigateur (recommandé pour limiter les interruptions).
        La synthèse et l’assistance peuvent être exclues (décoché par défaut). Stockage local, à remplacer par une politique serveur ou SSO en production.
      </p>
    </header>
    <div class="settings-sensitive-access-toolbar">
      <div class="settings-pref-row settings-sensitive-access-master">
        <span>Activer le code renforcé</span>
        <button type="button" class="settings-switch" role="switch" data-sa-master aria-label="Activer accès renforcé"></button>
      </div>
      <p class="settings-sensitive-access-hint" data-sa-status></p>
    </div>
    <div class="settings-subsection" data-sa-actions-wrap>
      <h5 class="settings-subsection__title">Types d’actions concernés</h5>
      <p class="settings-subsection__lead">Décochez pour laisser une catégorie sans demande de code (tant que le renfort est actif).</p>
      <div class="settings-sensitive-actions-grid" data-sa-actions></div>
    </div>
    <div class="settings-subsection" data-sa-freq-wrap>
      <h5 class="settings-subsection__title">Fréquence de la demande</h5>
      <p class="settings-subsection__lead settings-subsection__lead--tight">
        Une fois le code accepté, les actions protégées peuvent être débloquées pour toute la session (ou 15 min), selon votre choix.
      </p>
      <div class="settings-pref-row">
        <label class="settings-sensitive-select-label" for="settings-sa-frequency">Politique après saisie correcte</label>
        <select id="settings-sa-frequency" class="control-input" data-sa-frequency>
          <option value="per_session">Une fois par session (recommandé)</option>
          <option value="interval_15m">Au plus une fois toutes les 15 minutes</option>
          <option value="always">À chaque action protégée</option>
        </select>
      </div>
    </div>
    <div class="settings-subsection" data-sa-level-wrap>
      <h5 class="settings-subsection__title">Niveau de protection</h5>
      <div class="settings-pref-row">
        <label class="settings-sensitive-select-label" for="settings-sa-level">Affichage modal</label>
        <select id="settings-sa-level" class="control-input" data-sa-level>
          <option value="standard">Standard (sobre)</option>
          <option value="strict">Strict (rappel visuel renforcé)</option>
        </select>
      </div>
    </div>
    <div class="settings-subsection">
      <h5 class="settings-subsection__title">Code à 6 chiffres</h5>
      <p class="settings-subsection__lead">Même code pour toutes les actions cochées. Ne pas réutiliser un code bancaire.</p>
      <div class="settings-sensitive-pin-grid">
        <label class="field">
          <span>Nouveau code</span>
          <input type="password" class="control-input" data-sa-pin-a maxlength="6" inputmode="numeric" pattern="[0-9]*" autocomplete="new-password" placeholder="••••••" />
        </label>
        <label class="field">
          <span>Confirmer</span>
          <input type="password" class="control-input" data-sa-pin-b maxlength="6" inputmode="numeric" pattern="[0-9]*" autocomplete="new-password" placeholder="••••••" />
        </label>
      </div>
      <div class="settings-actions-bar" style="margin-top:12px">
        <button type="button" class="btn btn-primary" data-sa-pin-save>Enregistrer le code</button>
        <button type="button" class="btn btn-secondary" data-sa-pin-clear>Retirer le code</button>
      </div>
    </div>
  `;

  const saMaster = secH.querySelector('[data-sa-master]');
  const saStatus = secH.querySelector('[data-sa-status]');
  const saActionsHost = secH.querySelector('[data-sa-actions]');
  const saFreq = secH.querySelector('[data-sa-frequency]');
  const saLevel = secH.querySelector('[data-sa-level]');
  const saPinA = secH.querySelector('[data-sa-pin-a]');
  const saPinB = secH.querySelector('[data-sa-pin-b]');
  const saActionsWrap = secH.querySelector('[data-sa-actions-wrap]');
  const saFreqWrap = secH.querySelector('[data-sa-freq-wrap]');
  const saLevelWrap = secH.querySelector('[data-sa-level-wrap]');

  function persistSensitiveCfg() {
    saveSensitiveAccessConfig(sensitiveCfg);
  }

  function syncSensitiveAccessUi() {
    sensitiveCfg = loadSensitiveAccessConfig();
    if (saMaster) {
      saMaster.setAttribute('aria-checked', sensitiveCfg.enabled ? 'true' : 'false');
    }
    if (saStatus) {
      const pinOk = loadSensitiveAccessPin();
      saStatus.textContent = sensitiveCfg.enabled
        ? pinOk
          ? 'Code enregistré. Les actions cochées demanderont le code selon la fréquence choisie.'
          : 'Renfort activé mais aucun code : les actions protégées seront bloquées jusqu’à enregistrement d’un code.'
        : 'Accès renforcé désactivé. Aucune demande de code.';
    }
    const subOn = sensitiveCfg.enabled;
    [saActionsWrap, saFreqWrap, saLevelWrap].forEach((el) => {
      if (el) el.style.opacity = subOn ? '1' : '0.5';
    });
    if (saFreq) saFreq.disabled = !subOn;
    if (saLevel) saLevel.disabled = !subOn;
    if (saActionsHost) {
      saActionsHost.querySelectorAll('.settings-switch').forEach((sw) => {
        sw.toggleAttribute('disabled', !subOn);
      });
    }
    if (saFreq) saFreq.value = sensitiveCfg.frequency;
    if (saLevel) saLevel.value = sensitiveCfg.protectionLevel;
  }

  SENSITIVE_ACCESS_ACTION_META.forEach(({ key, label, hint }) => {
    const row = document.createElement('div');
    row.className = 'settings-sensitive-action-row';
    const text = document.createElement('div');
    const strong = document.createElement('strong');
    strong.textContent = label;
    const p = document.createElement('p');
    p.className = 'settings-sensitive-action-hint';
    p.textContent = hint;
    text.append(strong, p);
    const sw = document.createElement('button');
    sw.type = 'button';
    sw.className = 'settings-switch';
    sw.setAttribute('role', 'switch');
    sw.setAttribute('data-sa-act', key);
    sw.setAttribute('aria-label', label);
    sw.addEventListener('click', () => {
      if (!sensitiveCfg.enabled) return;
      const cur = Boolean(sensitiveCfg.actions[key]);
      sensitiveCfg = {
        ...sensitiveCfg,
        actions: { ...sensitiveCfg.actions, [key]: !cur }
      };
      sw.setAttribute('aria-checked', !cur ? 'true' : 'false');
      persistSensitiveCfg();
      clearSensitiveAccessSessionCache();
      syncSensitiveAccessUi();
      showToast('Paramètre enregistré (navigateur).', 'info');
    });
    row.append(text, sw);
    saActionsHost?.append(row);
  });

  saMaster?.addEventListener('click', () => {
    const next = !sensitiveCfg.enabled;
    sensitiveCfg = { ...sensitiveCfg, enabled: next };
    persistSensitiveCfg();
    if (!next) clearSensitiveAccessSessionCache();
    syncSensitiveAccessUi();
    showToast(next ? 'Accès renforcé activé.' : 'Accès renforcé désactivé.', 'info');
  });

  saFreq?.addEventListener('change', () => {
    const v = saFreq.value;
    if (v === 'always' || v === 'per_session' || v === 'interval_15m') {
      sensitiveCfg = { ...sensitiveCfg, frequency: v };
      persistSensitiveCfg();
      clearSensitiveAccessSessionCache();
      showToast('Fréquence enregistrée. La prochaine action demandera le code si nécessaire.', 'info');
    }
  });

  saLevel?.addEventListener('change', () => {
    const v = saLevel.value === 'strict' ? 'strict' : 'standard';
    sensitiveCfg = { ...sensitiveCfg, protectionLevel: v };
    persistSensitiveCfg();
    showToast('Niveau enregistré.', 'info');
  });

  secH.querySelector('[data-sa-pin-save]')?.addEventListener('click', () => {
    const a = String(saPinA?.value || '').replace(/\D/g, '');
    const b = String(saPinB?.value || '').replace(/\D/g, '');
    if (a.length !== 6 || b.length !== 6) {
      showToast('Saisissez deux fois un code à exactement 6 chiffres.', 'warning');
      return;
    }
    if (a !== b) {
      showToast('Les deux saisies ne correspondent pas.', 'warning');
      return;
    }
    saveSensitiveAccessPin(a);
    clearSensitiveAccessSessionCache();
    if (saPinA) saPinA.value = '';
    if (saPinB) saPinB.value = '';
    syncSensitiveAccessUi();
    showToast('Code enregistré localement.', 'info');
  });

  secH.querySelector('[data-sa-pin-clear]')?.addEventListener('click', () => {
    saveSensitiveAccessPin('');
    clearSensitiveAccessSessionCache();
    if (saPinA) saPinA.value = '';
    if (saPinB) saPinB.value = '';
    syncSensitiveAccessUi();
    showToast('Code retiré.', 'info');
  });

  syncSensitiveAccessUi();
  SENSITIVE_ACCESS_ACTION_META.forEach(({ key }) => {
    const sw = secH.querySelector(`[data-sa-act="${key}"]`);
    if (sw) sw.setAttribute('aria-checked', sensitiveCfg.actions[key] ? 'true' : 'false');
  });

  /* Référentiels */
  const secE = document.createElement('section');
  secE.className = 'settings-section';
  secE.id = 'settings-anchor-ref';
  secE.innerHTML = `
    <header class="settings-section__head">
      <p class="settings-section__kicker">E · Référentiels</p>
      <h4 class="settings-section__title">Référentiels</h4>
      <p class="settings-section__lead">
        Accès aux modules conformité et produits déjà en place (exigences, FDS, preuves).
      </p>
    </header>
    <div class="settings-actions-bar">
      <button type="button" class="btn btn-primary" data-settings-goto-iso>Ouvrir ISO &amp; Conformité</button>
      <button type="button" class="btn btn-secondary" data-settings-goto-products>Ouvrir Produits / FDS</button>
    </div>
  `;
  secE.querySelector('[data-settings-goto-iso]')?.addEventListener('click', () => goHash('iso'));
  secE.querySelector('[data-settings-goto-products]')?.addEventListener('click', () => goHash('products'));

  /* IA & validation */
  const IA_DEFAULTS = {
    iso: { enabled: true, mode: 'human' },
    imports: { enabled: true, mode: 'human' },
    audits: { enabled: true, mode: 'suggest' },
    risks: { enabled: false, mode: 'suggest' },
    aiCenter: { enabled: true, mode: 'suggest' }
  };
  let iaCfg = { ...IA_DEFAULTS, ...loadJson(LS_IA, {}) };
  const secF = document.createElement('section');
  secF.className = 'settings-section';
  secF.id = 'settings-anchor-ia';
  secF.innerHTML = `
    <header class="settings-section__head">
      <p class="settings-section__kicker">F · IA &amp; validation humaine</p>
      <h4 class="settings-section__title">IA &amp; validation humaine</h4>
      <p class="settings-section__lead">
        L’assistance propose ; l’humain valide, ajuste ou rejette. Les flux métiers (imports, NC, audits) restent sur leurs écrans.
        Ce bloc fixe la politique affichée côté configuration.
      </p>
    </header>
    <div class="settings-ia-human-pattern">
      <span class="settings-badge-ia">Suggestion assistée</span>
      <span class="settings-ia-human-pattern__cta">Valider · Modifier · Rejeter</span>
      <div class="settings-ia-state-strip">
        <span class="settings-ia-state-chip">En attente</span>
        <span class="settings-ia-state-chip">Validé</span>
        <span class="settings-ia-state-chip">Modifié</span>
        <span class="settings-ia-state-chip">Rejeté</span>
      </div>
    </div>
    <div class="settings-human-row" role="note">
      <span>Flux cible</span>
      <span style="color:var(--text3);font-weight:600">→</span>
      <span>Détection · contrôle humain · correction · vérification · clôture</span>
    </div>
    <div class="settings-ia-grid" data-settings-ia></div>
    <p class="settings-ia-states">
      <strong>Statuts de pilotage (affichage configuration) :</strong>
      en attente · validé · modifié · rejeté. À synchroniser avec les workflows NC, imports et audits côté API.
    </p>
  `;
  const iaHost = secF.querySelector('[data-settings-ia]');
  const iaModules = [
    { key: 'iso', label: 'ISO & Conformité (assistance exigence)' },
    { key: 'imports', label: 'Import documents (extraction)' },
    { key: 'audits', label: 'Audits & constats' },
    { key: 'risks', label: 'Risques' },
    { key: 'aiCenter', label: 'Synthèse et assistance (scénarios, assistant)' }
  ];
  function renderIaModules() {
    if (!iaHost) return;
    iaHost.replaceChildren();
    iaModules.forEach(({ key, label }) => {
      const base = IA_DEFAULTS[key] || { enabled: true, mode: 'human' };
      const cfg = {
        ...base,
        ...(typeof iaCfg[key] === 'object' && iaCfg[key] ? iaCfg[key] : {})
      };
      const box = document.createElement('div');
      box.className = 'settings-ia-module';
      const top = document.createElement('div');
      top.className = 'settings-ia-module__top';
      const h = document.createElement('p');
      h.className = 'settings-ia-module__name';
      h.textContent = label;
      const badge = document.createElement('span');
      badge.className = 'settings-badge-ia';
      badge.textContent = 'Suggestion assistée';
      const sw = document.createElement('button');
      sw.type = 'button';
      sw.className = 'settings-switch';
      sw.setAttribute('role', 'switch');
      sw.setAttribute('aria-checked', cfg.enabled ? 'true' : 'false');
      sw.setAttribute('aria-label', `Activer assistance ${label}`);
      sw.addEventListener('click', () => {
        iaCfg = {
          ...iaCfg,
          [key]: { ...cfg, enabled: !cfg.enabled }
        };
        saveJson(LS_IA, iaCfg);
        renderIaModules();
      });
      top.append(h, badge, sw);
      const modes = document.createElement('div');
      modes.className = 'settings-mode-row';
      const modesDef = [
        ['suggest', 'Suggestion seule'],
        ['human', 'Validation humaine obligatoire']
      ];
      modesDef.forEach(([m, lab]) => {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = `settings-mode-btn${cfg.mode === m ? ' settings-mode-btn--on' : ''}`;
        b.textContent = lab;
        b.addEventListener('click', () => {
          iaCfg = { ...iaCfg, [key]: { ...cfg, mode: m } };
          saveJson(LS_IA, iaCfg);
          renderIaModules();
        });
        modes.append(b);
      });
      box.append(top, modes);
      iaHost.append(box);
    });
  }
  renderIaModules();

  /* Cycle contrôle & correction */
  let cycle = {
    controlRequired: true,
    correctionRequired: true,
    revalidateAfterFix: true,
    revalidateScope: 'full',
    showRejectedInViews: true,
    controllerRole: 'Responsable qualité',
    correctorRole: 'Opérationnel terrain',
    validatorRole: 'Direction / QHSE',
    ...loadJson(LS_CYCLE, {})
  };
  if (!cycle.revalidateScope || typeof cycle.revalidateScope !== 'string') {
    cycle = { ...cycle, revalidateScope: 'full' };
  }

  let cycleUsage = normalizeCycleUsage(loadJson(LS_CYCLE_USAGE, {}));

  const secG = document.createElement('section');
  secG.className = 'settings-section settings-section--cycle-premium';
  secG.id = 'settings-anchor-cycle';
  secG.innerHTML = `
    <header class="settings-section__head">
      <p class="settings-section__kicker">G · Phases de contrôle et correction</p>
      <h4 class="settings-section__title">Phases de contrôle et de correction</h4>
      <p class="settings-section__lead">
        Pilotage crédible : détection, <strong>contrôle humain</strong>, correction, vérification, clôture. Pour
        <strong>prouver</strong> et <strong>décider</strong> sans sacrifier la traçabilité. Paramètres d’intention (local) prêts pour l’API.
      </p>
    </header>
    <div class="settings-cycle-parcours">
      <p class="settings-cycle-parcours__title">Parcours de maîtrise</p>
      <div class="settings-cycle-rail" role="img" aria-label="Cinq phases : détection, contrôle humain, correction, vérification, clôture">
        <div class="settings-cycle-rail__step">
          <span class="settings-cycle-rail__dot" aria-hidden="true"></span>
          <span class="settings-cycle-rail__name">Détection</span>
          <span class="settings-cycle-rail__hint">Signaux, imports, IA</span>
        </div>
        <div class="settings-cycle-rail__step">
          <span class="settings-cycle-rail__dot" aria-hidden="true"></span>
          <span class="settings-cycle-rail__name">Contrôle humain</span>
          <span class="settings-cycle-rail__hint">Revue &amp; arbitrage</span>
        </div>
        <div class="settings-cycle-rail__step">
          <span class="settings-cycle-rail__dot" aria-hidden="true"></span>
          <span class="settings-cycle-rail__name">Correction</span>
          <span class="settings-cycle-rail__hint">Actions &amp; plans</span>
        </div>
        <div class="settings-cycle-rail__step">
          <span class="settings-cycle-rail__dot" aria-hidden="true"></span>
          <span class="settings-cycle-rail__name">Vérification</span>
          <span class="settings-cycle-rail__hint">Preuves &amp; relecture</span>
        </div>
        <div class="settings-cycle-rail__step">
          <span class="settings-cycle-rail__dot" aria-hidden="true"></span>
          <span class="settings-cycle-rail__name">Clôture</span>
          <span class="settings-cycle-rail__hint">Validation finale</span>
        </div>
      </div>
    </div>
    <div class="settings-cycle-bridge">
      <p class="settings-cycle-bridge__title">Lecture transverse</p>
      <p class="settings-cycle-bridge__text">
        Les statuts <strong>à contrôler</strong>, <strong>à corriger</strong>, <strong>corrigé</strong>,
        <strong>à vérifier</strong>, <strong>validé</strong> et <strong>rejeté</strong> matérialisent l’avancement
        sur les flux IA, imports, extractions, écarts, audits et preuves, avec contrôle humain aux passages critiques.
      </p>
    </div>
    <div class="settings-subsection">
      <h5 class="settings-subsection__title">Applications par type d’usage</h5>
      <p class="settings-subsection__lead">
        Statut initial proposé à la création et obligation de passage humain (sans appel API sur cet écran).
      </p>
      <div class="settings-usage-matrix" data-settings-usage-matrix></div>
    </div>
    <div class="settings-subsection">
      <h5 class="settings-subsection__title">Chaîne opératoire</h5>
      <p class="settings-subsection__lead">Repère visuel aligné sur les étapes du cycle de maîtrise.</p>
      <div class="settings-cycle-map" aria-hidden="true">
        <span class="settings-cycle-map__step">1 · Détection</span>
        <span class="settings-cycle-map__arrow">→</span>
        <span class="settings-cycle-map__step">2 · Contrôle humain</span>
        <span class="settings-cycle-map__arrow">→</span>
        <span class="settings-cycle-map__step">3 · Correction</span>
        <span class="settings-cycle-map__arrow">→</span>
        <span class="settings-cycle-map__step">4 · Vérification</span>
        <span class="settings-cycle-map__arrow">→</span>
        <span class="settings-cycle-map__step">5 · Clôture</span>
      </div>
      <div class="settings-cycle-stepper" role="list">
        <div class="settings-cycle-step" role="listitem">
          <p class="settings-cycle-step__label">Détection</p>
          <p class="settings-cycle-step__hint">Signaux, imports, IA, audits</p>
        </div>
        <div class="settings-cycle-step" role="listitem">
          <p class="settings-cycle-step__label">Contrôle humain</p>
          <p class="settings-cycle-step__hint">Revue &amp; arbitrage</p>
        </div>
        <div class="settings-cycle-step" role="listitem">
          <p class="settings-cycle-step__label">Correction</p>
          <p class="settings-cycle-step__hint">Plans d’actions</p>
        </div>
        <div class="settings-cycle-step" role="listitem">
          <p class="settings-cycle-step__label">Vérification</p>
          <p class="settings-cycle-step__hint">Preuves &amp; relecture</p>
        </div>
        <div class="settings-cycle-step" role="listitem">
          <p class="settings-cycle-step__label">Clôture</p>
          <p class="settings-cycle-step__hint">Validation finale</p>
        </div>
      </div>
    </div>
    <div class="settings-subsection">
      <h5 class="settings-subsection__title">Règles globales du cycle</h5>
      <p class="settings-subsection__lead">Interrupteurs d’intention. Exécution métier inchangée sur les pages existantes.</p>
      <div class="settings-prefs-grid" data-settings-cycle-toggles></div>
      <div class="settings-pref-row" data-settings-revalidate-scope-wrap style="margin-top:10px"></div>
      <div class="settings-show-reject-row">
        <span>Afficher le statut <strong>Rejeté</strong> dans les vues de suivi (listes, badges, exports futurs).</span>
        <button type="button" class="settings-switch" role="switch" data-settings-cycle-reject-switch aria-label="Afficher rejeté"></button>
      </div>
    </div>
    <div class="settings-subsection">
      <h5 class="settings-subsection__title">Rôles responsables (libellés indicatifs)</h5>
      <p class="settings-subsection__lead">Contrôle, correction et validation finale. À mapper sur vos rôles SI.</p>
      <div class="settings-prefs-grid" data-settings-cycle-roles></div>
    </div>
    <div class="settings-subsection">
      <p class="settings-status-pills__cap">Statuts de suivi</p>
      <div class="settings-status-legend settings-status-pills" data-settings-status-pills>
        <span class="settings-pill settings-pill--watch">À contrôler</span>
        <span class="settings-pill settings-pill--fix">À corriger</span>
        <span class="settings-pill settings-pill--done">Corrigé</span>
        <span class="settings-pill settings-pill--verify">À vérifier</span>
        <span class="settings-pill settings-pill--ok">Validé</span>
        <span class="settings-pill settings-pill--reject settings-pill--muted">Rejeté</span>
      </div>
    </div>
  `;

  const usageHost = secG.querySelector('[data-settings-usage-matrix]');
  function persistCycleUsage() {
    saveJson(LS_CYCLE_USAGE, cycleUsage);
  }
  function redrawUsageMatrix() {
    if (!usageHost) return;
    usageHost.replaceChildren();
    USAGE_FLOW_ROWS.forEach(({ key, title, hint }) => {
      const u = cycleUsage[key];
      const card = document.createElement('div');
      card.className = 'settings-usage-card';
      const h5 = document.createElement('p');
      h5.className = 'settings-usage-card__title';
      h5.textContent = title;
      const hp = document.createElement('p');
      hp.className = 'settings-usage-card__hint';
      hp.textContent = hint;

      const row1 = document.createElement('div');
      row1.className = 'settings-usage-card__row';
      const l1 = document.createElement('label');
      l1.htmlFor = `settings-usage-st-${key}`;
      l1.textContent = 'Statut initial cible';
      const sel = document.createElement('select');
      sel.id = `settings-usage-st-${key}`;
      sel.className = 'control-input';
      STATUS_OPTIONS.forEach(([v, t]) => {
        const o = document.createElement('option');
        o.value = v;
        o.textContent = t;
        sel.append(o);
      });
      sel.value = u.defaultStatus;
      sel.addEventListener('change', () => {
        cycleUsage = {
          ...cycleUsage,
          [key]: { ...u, defaultStatus: sel.value }
        };
        persistCycleUsage();
        showToast('Paramètre enregistré (navigateur).', 'info');
      });
      row1.append(l1, sel);

      const row2 = document.createElement('div');
      row2.className = 'settings-usage-card__row';
      const l2 = document.createElement('span');
      l2.textContent = 'Contrôle humain requis avant diffusion';
      const sw = document.createElement('button');
      sw.type = 'button';
      sw.className = 'settings-switch';
      sw.setAttribute('role', 'switch');
      sw.setAttribute('aria-checked', u.humanRequired ? 'true' : 'false');
      sw.setAttribute('aria-label', `Contrôle humain pour ${title}`);
      sw.addEventListener('click', () => {
        const next = !cycleUsage[key].humanRequired;
        cycleUsage = {
          ...cycleUsage,
          [key]: { ...cycleUsage[key], humanRequired: next }
        };
        sw.setAttribute('aria-checked', next ? 'true' : 'false');
        persistCycleUsage();
        showToast('Paramètre enregistré (navigateur).', 'info');
      });
      row2.append(l2, sw);

      card.append(h5, hp, row1, row2);
      usageHost.append(card);
    });
  }
  redrawUsageMatrix();

  const cToggles = secG.querySelector('[data-settings-cycle-toggles]');
  if (cToggles) {
    [['controlRequired', 'Contrôle humain obligatoire'], ['correctionRequired', 'Correction obligatoire'], ['revalidateAfterFix', 'Revalidation après correction']].forEach(
      ([k, lab]) => {
        const row = document.createElement('div');
        row.className = 'settings-pref-row';
        const span = document.createElement('span');
        span.textContent = lab;
        const sw = document.createElement('button');
        sw.type = 'button';
        sw.className = 'settings-switch';
        sw.setAttribute('role', 'switch');
        sw.setAttribute(
          'aria-label',
          `${lab} : ${cycle[k] ? 'activé' : 'désactivé'}`
        );
        sw.setAttribute('aria-checked', !!cycle[k] ? 'true' : 'false');
        sw.addEventListener('click', () => {
          const next = !cycle[k];
          cycle = { ...cycle, [k]: next };
          sw.setAttribute('aria-checked', next ? 'true' : 'false');
          sw.setAttribute(
            'aria-label',
            `${lab} : ${next ? 'activé' : 'désactivé'}`
          );
          saveJson(LS_CYCLE, cycle);
          showToast('Paramètre cycle enregistré (navigateur).', 'info');
        });
        row.append(span, sw);
        cToggles.append(row);
      }
    );
  }

  const revScopeWrap = secG.querySelector('[data-settings-revalidate-scope-wrap]');
  if (revScopeWrap) {
    const lab = document.createElement('span');
    lab.style.maxWidth = '48ch';
    lab.style.lineHeight = '1.45';
    lab.innerHTML =
      '<strong style="color:var(--text)">Portée de la revalidation</strong> après correction <span style="opacity:.8;font-weight:500">(réglage local)</span>';
    const sel = document.createElement('select');
    sel.className = 'control-input';
    sel.setAttribute('aria-label', 'Portée de la revalidation après correction');
    [
      ['full', 'Relecture complète des preuves'],
      ['targeted', 'Points sensibles uniquement'],
      ['procedural', 'Contrôle documentaire (sans terrain)']
    ].forEach(([v, t]) => {
      const o = document.createElement('option');
      o.value = v;
      o.textContent = t;
      sel.append(o);
    });
    sel.value =
      ['full', 'targeted', 'procedural'].includes(String(cycle.revalidateScope))
        ? String(cycle.revalidateScope)
        : 'full';
    sel.addEventListener('change', () => {
      cycle = { ...cycle, revalidateScope: sel.value };
      saveJson(LS_CYCLE, cycle);
      showToast('Portée de revalidation enregistrée (navigateur).', 'info');
    });
    revScopeWrap.append(lab, sel);
  }

  const rejectSw = secG.querySelector('[data-settings-cycle-reject-switch]');
  if (rejectSw) {
    rejectSw.setAttribute('aria-checked', cycle.showRejectedInViews !== false ? 'true' : 'false');
    rejectSw.addEventListener('click', () => {
      const next = !(cycle.showRejectedInViews !== false);
      cycle = { ...cycle, showRejectedInViews: next };
      rejectSw.setAttribute('aria-checked', next ? 'true' : 'false');
      saveJson(LS_CYCLE, cycle);
      showToast('Préférence enregistrée (navigateur).', 'info');
    });
  }

  const cRoles = secG.querySelector('[data-settings-cycle-roles]');
  if (cRoles) {
    [
      ['controllerRole', 'Rôle responsable du contrôle'],
      ['correctorRole', 'Rôle responsable de la correction'],
      ['validatorRole', 'Rôle validation / clôture']
    ].forEach(([k, lab]) => {
      const row = document.createElement('div');
      row.className = 'settings-pref-row';
      row.style.flexDirection = 'column';
      row.style.alignItems = 'stretch';
      const l = document.createElement('span');
      l.textContent = lab;
      const inp = document.createElement('input');
      inp.type = 'text';
      inp.className = 'control-input';
      inp.value = String(cycle[k] || '');
      inp.addEventListener('change', () => {
        cycle = { ...cycle, [k]: inp.value };
        saveJson(LS_CYCLE, cycle);
      });
      row.append(l, inp);
      cRoles.append(row);
    });
  }

  const secUsers = document.createElement('section');
  secUsers.className = 'settings-section';
  secUsers.id = 'settings-anchor-users';
  secUsers.innerHTML = `
    <header class="settings-section__head">
      <p class="settings-section__kicker">I · Gestion des utilisateurs</p>
      <h4 class="settings-section__title">Utilisateurs</h4>
      <p class="settings-section__lead">Liste, création, rôle, mot de passe (8+ caractères : au moins une lettre et un chiffre). Retirer un membre le détache de <strong>cette organisation</strong> uniquement (son compte peut exister ailleurs).</p>
    </header>
    <div class="settings-actions-bar" style="display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px" data-users-form>
      <input class="control-input" placeholder="Nom" data-users-name />
      <input class="control-input" placeholder="Email" data-users-email />
      <select class="control-input" data-users-role>
        <option value="ADMIN">ADMIN</option>
        <option value="QHSE">QHSE</option>
        <option value="DIRECTION">DIRECTION</option>
        <option value="ASSISTANT">ASSISTANT</option>
        <option value="TERRAIN">TERRAIN</option>
      </select>
      <input class="control-input" placeholder="Mot de passe" data-users-password />
    </div>
    <div class="settings-actions-bar">
      <button type="button" class="btn btn-primary" data-users-add>Ajouter utilisateur</button>
    </div>
    <div class="settings-alert-list" data-users-list></div>
  `;

  const usersListHost = secUsers.querySelector('[data-users-list]');
  const uName = secUsers.querySelector('[data-users-name]');
  const uEmail = secUsers.querySelector('[data-users-email]');
  const uRole = secUsers.querySelector('[data-users-role]');
  const uPass = secUsers.querySelector('[data-users-password]');
  const currentUserId = String(getSessionUser()?.id || '');

  const USER_ROLE_OPTIONS = ['ADMIN', 'QHSE', 'DIRECTION', 'ASSISTANT', 'TERRAIN'];

  function roleSelectOptions(currentRole) {
    const cur = String(currentRole || '').toUpperCase();
    const base = [...USER_ROLE_OPTIONS];
    if (cur && !base.includes(cur)) base.unshift(cur);
    return base;
  }

  async function loadUsers() {
    if (!usersListHost) return;
    usersListHost.replaceChildren();
    const loadingMsg = document.createElement('p');
    loadingMsg.className = 'settings-alert-meta';
    loadingMsg.textContent = 'Chargement utilisateurs...';
    usersListHost.append(loadingMsg);
    try {
      const res = await qhseFetch('/api/users');
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const list = await res.json().catch(() => []);
      usersListHost.replaceChildren();
      (Array.isArray(list) ? list : []).forEach((u) => {
        const row = document.createElement('div');
        row.className = 'settings-alert-row';
        const main = document.createElement('div');
        main.className = 'settings-alert-main';
        const nameP = document.createElement('p');
        nameP.className = 'settings-alert-name';
        nameP.textContent = u.name || 'Non renseigné';
        const emailP = document.createElement('p');
        emailP.className = 'settings-alert-meta';
        emailP.textContent = u.email || '';
        main.append(nameP, emailP);
        const actions = document.createElement('div');
        actions.className = 'settings-actions-bar';
        const roleSel = document.createElement('select');
        roleSel.className = 'control-input';
        roleSelectOptions(u.role).forEach((r) => {
          const o = document.createElement('option');
          o.value = r;
          o.textContent = r;
          if (String(u.role || '').toUpperCase() === String(r).toUpperCase()) o.selected = true;
          roleSel.append(o);
        });
        roleSel.addEventListener('change', async () => {
          try {
            const r = await qhseFetch(`/api/users/${encodeURIComponent(String(u.id))}`, {
              method: 'PATCH',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ role: roleSel.value, name: u.name })
            });
            if (!r.ok) {
              const { message } = await readFailedApiResponse(r);
              showToast(message || `Mise à jour impossible (HTTP ${r.status}).`, 'error');
              return;
            }
            showToast('Rôle utilisateur mis à jour.', 'success');
          } catch {
            showToast('Mise à jour rôle impossible.', 'error');
          }
        });
        const del = document.createElement('button');
        del.type = 'button';
        del.className = 'btn btn-secondary';
        del.textContent = 'Retirer';
        del.title =
          'Retirer cette personne de l’organisation courante (sans supprimer son compte sur d’autres organisations).';
        del.setAttribute(
          'aria-label',
          `Retirer ${u.name || u.email || 'ce membre'} de l’organisation`
        );
        const pwdBar = document.createElement('div');
        pwdBar.className = 'settings-actions-bar';
        pwdBar.style.flexWrap = 'wrap';
        pwdBar.style.marginTop = '6px';
        const pwdInput = document.createElement('input');
        pwdInput.type = 'password';
        pwdInput.className = 'control-input';
        pwdInput.placeholder = 'Nouveau mot de passe';
        pwdInput.autocomplete = 'new-password';
        pwdInput.style.minWidth = '160px';
        const pwdConfirm = document.createElement('input');
        pwdConfirm.type = 'password';
        pwdConfirm.className = 'control-input';
        pwdConfirm.placeholder = 'Confirmer le mot de passe';
        pwdConfirm.autocomplete = 'new-password';
        pwdConfirm.style.minWidth = '160px';
        const pwdBtn = document.createElement('button');
        pwdBtn.type = 'button';
        pwdBtn.className = 'btn btn-secondary';
        pwdBtn.textContent = 'Définir le mot de passe';
        pwdBtn.addEventListener('click', async () => {
          const pwd = String(pwdInput.value || '');
          const confirmPwd = String(pwdConfirm.value || '');
          if (!pwd.trim()) {
            showToast('Saisir un mot de passe.', 'error');
            return;
          }
          if (pwd.length < 8) {
            showToast('Mot de passe trop court (minimum 8 caractères).', 'error');
            return;
          }
          if (pwd !== confirmPwd) {
            showToast('La confirmation du mot de passe ne correspond pas.', 'error');
            return;
          }
          try {
            const r = await qhseFetch(`/api/users/${encodeURIComponent(String(u.id))}`, {
              method: 'PATCH',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ password: pwd })
            });
            if (!r.ok) {
              const { message } = await readFailedApiResponse(r);
              showToast(message || `Mise à jour impossible (HTTP ${r.status}).`, 'error');
              return;
            }
            pwdInput.value = '';
            pwdConfirm.value = '';
            showToast('Mot de passe enregistré. La personne peut se connecter avec cet e-mail.', 'success');
          } catch {
            showToast('Enregistrement du mot de passe impossible.', 'error');
          }
        });
        pwdBar.append(pwdInput, pwdConfirm, pwdBtn);

        del.addEventListener('click', async () => {
          if (currentUserId && String(u.id) === currentUserId) {
            showToast('Vous ne pouvez pas retirer votre propre accès depuis cette page.', 'warning');
            return;
          }
          if (
            !window.confirm(
              `Retirer ${u.name || u.email} de cette organisation ? La personne perdra l’accès à cet espace ; son compte peut rester actif ailleurs.`
            )
          ) {
            return;
          }
          try {
            const r = await qhseFetch(`/api/users/${encodeURIComponent(String(u.id))}`, {
              method: 'DELETE'
            });
            if (!r.ok) {
              const { body, message } = await readFailedApiResponse(r);
              if (r.status === 409 && body.code === 'USER_HAS_ACTIONS') {
                const n = body.assignedActionCount;
                const countLabel =
                  typeof n === 'number' && n > 1
                    ? `${n} actions`
                    : typeof n === 'number' && n === 1
                      ? '1 action'
                      : 'les actions';
                const detail =
                  message ||
                  'Des actions de cette organisation sont encore assignées à cette personne.';
                const retry = window.confirm(
                  `${detail}\n\nDésassigner ${countLabel} sur cette organisation et retirer ce membre ?`
                );
                if (!retry) return;
                const r2 = await qhseFetch(
                  `/api/users/${encodeURIComponent(String(u.id))}?unassignActions=1`,
                  { method: 'DELETE' }
                );
                if (!r2.ok) {
                  const { message: m2 } = await readFailedApiResponse(r2);
                  showToast(m2 || `Retrait impossible (HTTP ${r2.status}).`, 'error');
                  return;
                }
                showToast('Actions désassignées et membre retiré.', 'success');
                await loadUsers();
                return;
              }
              if (r.status === 403) {
                showToast(
                  message || 'Action interdite pour ce compte.',
                  'warning'
                );
              } else if (r.status === 409) {
                showToast(
                  message ||
                    'Retrait impossible : des actions de cette organisation sont encore assignées à cette personne.',
                  'warning'
                );
              } else {
                showToast(message || `Retrait impossible (HTTP ${r.status}).`, 'error');
              }
              return;
            }
            showToast('Membre retiré de cette organisation.', 'success');
            await loadUsers();
          } catch {
            showToast('Retrait impossible.', 'error');
          }
        });
        actions.append(roleSel, del);
        const actionsCol = document.createElement('div');
        actionsCol.style.display = 'flex';
        actionsCol.style.flexDirection = 'column';
        actionsCol.style.gap = '0';
        actionsCol.append(actions, pwdBar);
        row.append(main, actionsCol);
        usersListHost.append(row);
      });
    } catch {
      usersListHost.replaceChildren();
      const errP = document.createElement('p');
      errP.className = 'settings-alert-meta';
      errP.textContent = 'Chargement utilisateurs indisponible.';
      usersListHost.append(errP);
      showToast('Impossible de charger les utilisateurs.', 'warning');
    }
  }

  secUsers.querySelector('[data-users-add]')?.addEventListener('click', async () => {
    const name = String(uName?.value || '').trim();
    const email = String(uEmail?.value || '').trim();
    const role = String(uRole?.value || 'QHSE');
    const password = String(uPass?.value || '').trim();
    if (!name || !email || !password) {
      showToast('Nom, email et mot de passe requis.', 'error');
      return;
    }
    const pvNew = validatePasswordPolicy(password);
    if (!pvNew.ok) {
      showToast(pvNew.error, 'error');
      return;
    }
    try {
      const r = await qhseFetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, role, password })
      });
      if (!r.ok) {
        const { message } = await readFailedApiResponse(r);
        showToast(message || `Création impossible (HTTP ${r.status}).`, 'error');
        return;
      }
      showToast('Utilisateur créé.', 'success');
      if (uName) uName.value = '';
      if (uEmail) uEmail.value = '';
      if (uPass) uPass.value = '';
      await loadUsers();
    } catch {
      showToast('Création utilisateur impossible.', 'error');
    }
  });

  void loadUsers();

  const secHelp = document.createElement('section');
  secHelp.className = 'settings-section';
  secHelp.id = 'settings-anchor-help';
  secHelp.setAttribute('aria-labelledby', 'settings-help-title');
  secHelp.innerHTML = `
    <header class="settings-section__head">
      <p class="settings-section__kicker">Aide &amp; support</p>
      <h4 class="settings-section__title" id="settings-help-title">Documentation utilisateur</h4>
      <p class="settings-section__lead">
        Téléchargez le guide PDF pour la prise en main des modules (dashboard, incidents, risques, audits, modes Essentiel / Expert, etc.).
      </p>
    </header>
    <div class="content-card card-soft">
      <p class="settings-demo-hint" style="margin:0">
        <a href="/guide-utilisateur-africaqhse.pdf" class="btn btn-secondary" target="_blank" rel="noopener noreferrer">Télécharger le guide utilisateur (PDF)</a>
      </p>
      <p class="settings-section__lead" style="margin:14px 0 0;font-size:13px;line-height:1.5;color:var(--text2,#94a3b8)">
        Besoin d’aide sur l’application : <a href="mailto:support@qhsecontrol.com">support@qhsecontrol.com</a>.
        Compte client ou accompagnement : <a href="mailto:direction@qhsecontrol.com">direction@qhsecontrol.com</a>.
        Devis ou offre Pro : <a href="mailto:devis@qhsecontrol.com?subject=Demande%20QHSE%20Control%20Pro">devis@qhsecontrol.com</a>.
        Facturation : <a href="mailto:facturation@qhsecontrol.com">facturation@qhsecontrol.com</a>.
        Contact général : <a href="mailto:contact@qhsecontrol.com">contact@qhsecontrol.com</a>.
      </p>
    </div>
  `;

  const replayBtn = document.createElement('button');
  replayBtn.type = 'button';
  replayBtn.textContent = 'Revoir le guide de demarrage';
  replayBtn.className = 'btn btn-ghost btn-sm';
  replayBtn.style.marginTop = '8px';
  replayBtn.addEventListener('click', () => {
    localStorage.removeItem('qhse_onboarding_done_v1');
    import('../components/onboardingWizard.js').then((m) => m.showOnboardingWizard());
  });
  secHelp.querySelector('.content-card.card-soft')?.append(replayBtn);

  page.append(
    hero,
    ...(secDemo ? [secDemo] : []),
    secA,
    secB,
    secC,
    ...(secEmail ? [secEmail] : []),
    secD,
    secH,
    secE,
    secF,
    secG,
    secUsers,
    secHelp
  );
  try {
    const focus = sessionStorage.getItem('qhse_settings_focus');
    if (focus) {
      sessionStorage.removeItem('qhse_settings_focus');
      requestAnimationFrame(() => scrollToSettingsSection(focus));
    }
  } catch {
    /* ignore */
  }
  return page;
}
